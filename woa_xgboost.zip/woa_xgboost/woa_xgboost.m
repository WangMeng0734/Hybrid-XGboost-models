
warning off           
close all               
clear                   
clc                     

%% Importing Data
res = xlsread('data.xlsx');

%%  Data analysis
num_size = 0.64;                              
outdim = 1;                                  
num_samples = size(res, 1);                  
%res = res(randperm(num_samples), :);         
num_train_s = round(num_size * num_samples); 
f_ = size(res, 2) - outdim;                 

%% Divide the training set and test set
P_train = res(1: num_train_s, 1: f_)';
T_train = res(1: num_train_s, f_ + 1: end)';
M = size(P_train, 2);

P_test = res(num_train_s + 1: end, 1: f_)';
T_test = res(num_train_s + 1: end, f_ + 1: end)';
N = size(P_test, 2);

%%  Data Normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%%  Data Transposition
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';
%% 
SearchAgents_no = 25;     
Max_iter = 50;       
dim = 3;                 
lb = [1,0.1,0.01];        
ub = [200,1,1];        
% initialize position vector and score for the leader
Leader_pos=zeros(1,dim);
Leader_score=inf; %change this to -inf for maximization problems


%Initialize the positions of search agents
Positions=initialization(SearchAgents_no,dim,ub,lb);

Convergence_curve=zeros(1,Max_iter);

t=0;% Loop counter

% Main loop
while t<Max_iter
    for i=1:size(Positions,1)
        
        % Return back the search agents that go beyond the boundaries of
        % the search space
        Flag4ub=Positions(i,:)>ub;
        Flag4lb=Positions(i,:)<lb;
        Positions(i,:)=(Positions(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        
        % Calculate objective function for each search agent
        num_trees = Positions(i,1);                  
        params.eta = Positions(i,2);                
        params.objective = 'reg:linear';  
        params.max_depth = 3;             
        params.reg_lambda = Positions(i,3);        

        %% Building the Model
        model = xgboost_train(p_train, t_train, params, num_trees);

        %%  predict
        t_sim1 = xgboost_test(p_train, model);


        %%  Data denormalization
         T_sim1 = mapminmax('reverse', t_sim1', ps_output);
         fitness = sum((T_sim1 - T_train ).^2) ./ M;
        
        if fitness<Leader_score % Change this to > for maximization problem
            Leader_score=fitness; % Update alpha
            Leader_pos=Positions(i,:);
        end
        
    end
    
    a=2-t*((2)/Max_iter); % a decreases linearly from 2 to 0 in Eq. (2.3)
    
    % a2 linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
    a2=-1+t*((-1)/Max_iter);
    
    % Update the Position of search agents
    for i=1:size(Positions,1)
        r1=rand(); % r1 is a random number in [0,1]
        r2=rand(); % r2 is a random number in [0,1]
        
        A=2*a*r1-a;  % Eq. (2.3) in the paper
        C=2*r2;      % Eq. (2.4) in the paper
        
        
        b=1;               %  parameters in Eq. (2.5)
        l=(a2-1)*rand+1;   %  parameters in Eq. (2.5)
        
        p = rand();        % p in Eq. (2.6)
        
        for j=1:size(Positions,2)
            
            if p<0.5   
                if abs(A)>=1
                    rand_leader_index = floor(SearchAgents_no*rand()+1);
                    X_rand = Positions(rand_leader_index, :);
                    D_X_rand=abs(C*X_rand(j)-Positions(i,j)); % Eq. (2.7)
                    Positions(i,j)=X_rand(j)-A*D_X_rand;      % Eq. (2.8)
                    
                elseif abs(A)<1
                    D_Leader=abs(C*Leader_pos(j)-Positions(i,j)); % Eq. (2.1)
                    Positions(i,j)=Leader_pos(j)-A*D_Leader;      % Eq. (2.2)
                end
                
            elseif p>=0.5
              
                distance2Leader=abs(Leader_pos(j)-Positions(i,j));
                % Eq. (2.5)
                Positions(i,j)=distance2Leader*exp(b.*l).*cos(l.*2*pi)+Leader_pos(j);
                
            end
            
        end
    end
    t=t+1;
    Convergence_curve(t)=Leader_score;
end 
%  Setting parameters
num_trees = Leader_pos(1,1);                 
params.eta = Leader_pos(1,2);               
params.objective = 'reg:linear';  
params.max_depth = 3;             
params.reg_lambda = Leader_pos(1,3);         


%%  Building the Model
model = xgboost_train(p_train, t_train, params, num_trees);
% importance = model.importance;

%%  predict
t_sim1 = xgboost_test(p_train, model);
t_sim2 = xgboost_test(p_test,  model);

%%  Data denormalization
T_sim1 = mapminmax('reverse', t_sim1', ps_output);
T_sim2 = mapminmax('reverse', t_sim2', ps_output);

%%  Root mean square error
error1 = sqrt(sum((T_sim1 - T_train).^2) ./ M);
error2 = sqrt(sum((T_sim2 - T_test ).^2) ./ N);


figure
plot(1: M, T_train, 'r-*', 1: M, T_sim1, 'b-o', 'LineWidth', 1)
legend('True value','Predicted value')
xlabel('Prediction Sample')
ylabel('Prediction results')
string = {'Comparison of prediction results of training set';['RMSE=' num2str(error1)]};
title(string)
xlim([1, M])
grid

figure
plot(1: N, T_test, 'r-*', 1: N, T_sim2, 'b-o', 'LineWidth', 1)
legend('True value','Predicted value')
xlabel('Prediction Sample')
ylabel('Prediction results')
string = {'Comparison of prediction results of test set';['RMSE=' num2str(error2)]};
title(string)
xlim([1, N])
grid
%%   Fitness curve
figure
plot(1 : length(Convergence_curve), Convergence_curve, 'LineWidth', 1.5);
title('Fitness curve', 'FontSize', 13);
xlabel('Iterations', 'FontSize', 10);
ylabel('Fitness value', 'FontSize', 10);
xlim([1, length(Convergence_curve)])
grid on
%% Related indicator calculation
% R2
R1 = 1 - norm(T_train - T_sim1)^2 / norm(T_train - mean(T_train))^2;
R2 = 1 - norm(T_test -  T_sim2)^2 / norm(T_test -  mean(T_test ))^2;

disp(['The R2 of the training set data is��', num2str(R1)])
disp(['The R2 of the test set data is��', num2str(R2)])

%  MAE
mae1 = sum(abs(T_sim1 - T_train)) ./ M ;
mae2 = sum(abs(T_sim2 - T_test )) ./ N ;


disp(['The MAE of the training set data is��', num2str(mae1)])
disp(['The MAE of the test set data is��', num2str(mae2)])

%  MBE
mbe1 = sum(T_sim1 - T_train) ./ M ;
mbe2 = sum(T_sim2 - T_test ) ./ N ;

disp(['The MBE of the training set data is��', num2str(mbe1)])
disp(['The MBE of the test set data is��', num2str(mbe2)])

%RMSE
disp(['The RMSE of the training set data is��', num2str(error1)])
disp(['The RMSE of the test set data is��', num2str(error2)])
