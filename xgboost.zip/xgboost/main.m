
warning off            
close all               
clear                   
clc                   


res = xlsread('data.xlsx');

%% Data analysis
num_size = 0.8;                            
outdim = 1;                                
num_samples = size(res, 1);                  
res = res(randperm(num_samples), :);      
num_train_s = round(num_size * num_samples); 
f_ = size(res, 2) - outdim;                 

%%  Divide the training set and test set
P_train = res(1: num_train_s, 1: f_)';
T_train = res(1: num_train_s, f_ + 1: end)';
M = size(P_train, 2);

P_test = res(num_train_s + 1: end, 1: f_)';
T_test = res(num_train_s + 1: end, f_ + 1: end)';
N = size(P_test, 2);

%%  Data Normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%%  Data Transposition
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';
 
%%  Setting parameters
num_trees = 100;                  
params.eta = 0.3;                 
params.objective = 'reg:linear';  
params.max_depth = 3;             
params.reg_lambda = 0;

%%  Building the Model
model = xgboost_train(p_train, t_train, params, num_trees);

%%  predict
t_sim1 = xgboost_test(p_train, model);
t_sim2 = xgboost_test(p_test,  model);

%%  Data denormalization
T_sim1 = mapminmax('reverse', t_sim1', ps_output);
T_sim2 = mapminmax('reverse', t_sim2', ps_output);

%%  Root mean square error
error1 = sqrt(sum((T_sim1 - T_train).^2) ./ M);
error2 = sqrt(sum((T_sim2 - T_test ).^2) ./ N);
%% 
save model.mat

%%  Drawing
figure
plot(1: M, T_train, 'r-*', 1: M, T_sim1, 'b-o', 'LineWidth', 1)
legend('True value','Predicted value')
xlabel('Prediction Sample')
ylabel('Prediction results')
string = {'Comparison of prediction results of training set'; ['RMSE=' num2str(error1)]};
title(string)
xlim([1, M])
grid

figure
plot(1: N, T_test, 'r-*', 1: N, T_sim2, 'b-o', 'LineWidth', 1)
legend('True value','Predicted value')
xlabel('Prediction Sample')
ylabel('Prediction results')
string = {'Comparison of prediction results of test set';['RMSE=' num2str(error2)]};
title(string)
xlim([1, N])
grid

%% Related indicator calculation
% R2
R1 = 1 - norm(T_train - T_sim1)^2 / norm(T_train - mean(T_train))^2;
R2 = 1 - norm(T_test -  T_sim2)^2 / norm(T_test -  mean(T_test ))^2;

disp(['The R2 of the training set data is：', num2str(R1)])
disp(['The R2 of the test set data is：', num2str(R2)])

%  MAE
mae1 = sum(abs(T_sim1 - T_train)) ./ M ;
mae2 = sum(abs(T_sim2 - T_test )) ./ N ;

disp(['The MAE of the training set data is：', num2str(mae1)])
disp(['The MAE of the test set data is：', num2str(mae2)])

%  MBE
mbe1 = sum(T_sim1 - T_train) ./ M ;
mbe2 = sum(T_sim2 - T_test ) ./ N ;


disp(['The MBE of the training set data is：', num2str(mbe1)])
disp(['The MBE of the test set data is：', num2str(mbe2)])