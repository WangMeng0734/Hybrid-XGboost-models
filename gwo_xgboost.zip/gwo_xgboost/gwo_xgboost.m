
warning off          
close all             
clear                  
clc                    

res = xlsread('data.xlsx');

%% Data analysis
num_size = 0.8;                              
outdim = 1;                                 
num_samples = size(res, 1);                  
res = res(randperm(num_samples), :);        
num_train_s = round(num_size * num_samples); 
f_ = size(res, 2) - outdim;
                 
%%  Divide the training set and test set
P_train = res(1: num_train_s, 1: f_)';
T_train = res(1: num_train_s, f_ + 1: end)';
M = size(P_train, 2);

P_test = res(num_train_s + 1: end, 1: f_)';
T_test = res(num_train_s + 1: end, f_ + 1: end)';
N = size(P_test, 2);

%%  Data Normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%%  Data Transposition
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';
%%  Parameter settings
SearchAgents_no = 100;     
Max_iteration = 100;       
dim = 3;                  
lb = [1,0.1,0.01];      
ub = [200,1,0.5];        

%%  Optimization algorithm initialization
Alpha_pos = zeros(1, dim);  
Alpha_score = inf;          

Beta_pos = zeros(1, dim);  
Beta_score = inf;           

Delta_pos = zeros(1, dim);  
Delta_score = inf;        

%%  Initialize the search for the wolf pack's location
Positions = initialization(SearchAgents_no, dim, ub, lb);

%%  Used to record iteration curves
Convergence_curve = zeros(1, Max_iteration);

%% Cycle Counter
iter = 0;                          

%%  Optimizing the algorithm main loop
while iter < Max_iteration          
    for i = 1 : size(Positions, 1)   


        Flag4ub = Positions(i, :) > ub;
        Flag4lb = Positions(i, :) < lb;

      
        Positions(i, :) = (Positions(i, :) .* (~(Flag4ub + Flag4lb))) + ub .* Flag4ub + lb .* Flag4lb;          

       % Calculate objective function for each search agent
        num_trees = Positions(i,1);                  
        params.eta = Positions(i,2);                
        params.objective = 'reg:linear'; 
        params.max_depth = 3;            
        params.reg_lambda = Positions(i,3);         

        %%  Building the Model
        model = xgboost_train(p_train, t_train, params, num_trees);

        %%  predict
        t_sim1 = xgboost_test(p_train, model);
%       t_sim2 = xgboost_test(p_test,  model);

        %%  Data denormalization
        T_sim1 = mapminmax('reverse', t_sim1', ps_output);
%       T_sim2 = mapminmax('reverse', t_sim2', ps_output);
        fitness = sum((T_sim1 - T_train ).^2) ./ M;

        %%  updata Alpha, Beta, Delta
        if fitness < Alpha_score           
            Alpha_score = fitness;        
            Alpha_pos = Positions(i, :);  
        end

        if fitness > Alpha_score && fitness < Beta_score   
            Beta_score = fitness;                          
            Beta_pos = Positions(i, :);               
        end

        if fitness > Alpha_score && fitness > Beta_score && fitness < Delta_score  
            Delta_score = fitness;                                                 
            Delta_pos = Positions(i, :);                                           
        end

    end

    % Linear weight reduction
    wa = 2 - iter * ((2) / Max_iteration);    

    % Updated search for wolf locations
    for i = 1 : size(Positions, 1)      
        for j = 1 : size(Positions, 2)  

            % Surround the prey, position update
            r1 = rand; % r1 is a random number in [0,1]
            r2 = rand; % r2 is a random number in [0,1]

            A1 = 2 * wa * r1 - wa;   
            C1 = 2 * r2;             

            % Alpha position updates
            D_alpha = abs(C1 * Alpha_pos(j) - Positions(i, j));   
            X1 = Alpha_pos(j) - A1 * D_alpha;                     

            r1 = rand; % r1 is a random number in [0,1]
            r2 = rand; % r2 is a random number in [0,1]

            A2 = 2 * wa * r1 - wa;  
            C2 = 2 *r2;             

            % Beta Location Updates
            D_beta = abs(C2 * Beta_pos(j) - Positions(i, j));   
            X2 = Beta_pos(j) - A2 * D_beta;                    

            r1 = rand;  % r1 is a random number in [0,1]
            r2 = rand;  % r2 is a random number in [0,1]

            A3 = 2 *wa * r1 - wa;     
            C3 = 2 *r2;              

            % Delta Position Updates
            D_delta = abs(C3 * Delta_pos(j) - Positions(i, j));   
            X3 = Delta_pos(j) - A3 * D_delta;                    

            % Location Updates
            Positions(i, j) = (X1 + X2 + X3) / 3;                 

        end
    end

    % Update iterator
    iter = iter + 1;    
    Convergence_curve(iter) = Alpha_score;

end
%%  Setting parameters
num_trees = Alpha_pos(1,1);                  
params.eta = Alpha_pos(1,2);                
params.objective = 'reg:linear';  
params.max_depth = 3;             
 params.reg_lambda = Alpha_pos(1,3);         
%%  Building the Model
model = xgboost_train(p_train, t_train, params, num_trees);
% importance = model.importance; 
%%  predict
t_sim1 = xgboost_test(p_train, model);
t_sim2 = xgboost_test(p_test,  model);

%%  Data denormalization
T_sim1 = mapminmax('reverse', t_sim1', ps_output);
T_sim2 = mapminmax('reverse', t_sim2', ps_output);

%%  Root mean square error
error1 = sqrt(sum((T_sim1 - T_train).^2) ./ M);
error2 = sqrt(sum((T_sim2 - T_test ).^2) ./ N);

%%  Drawing
figure
plot(1: M, T_train, 'r-*', 1: M, T_sim1, 'b-o', 'LineWidth', 1)
legend('True value','Predicted value')
xlabel('Prediction Sample')
ylabel('Prediction results')
string = {'Comparison of prediction results of training set'; ['RMSE=' num2str(error1)]};
title(string)
xlim([1, M])
grid

figure
plot(1: N, T_test, 'r-*', 1: N, T_sim2, 'b-o', 'LineWidth', 1)
legend('True value','Predicted value')
xlabel('Prediction Sample')
ylabel('Prediction results')
string = {'Comparison of prediction results of test set';['RMSE=' num2str(error2)]};
title(string)
xlim([1, N])
grid
%%  Fitness curve
figure
plot(1 : length(Convergence_curve), Convergence_curve, 'LineWidth', 1.5);
title('Fitness curve', 'FontSize', 13);
xlabel('Iterations', 'FontSize', 10);
ylabel('Fitness value', 'FontSize', 10);
xlim([1, length(Convergence_curve)])
grid on
%% Related indicator calculation
% R2
R1 = 1 - norm(T_train - T_sim1)^2 / norm(T_train - mean(T_train))^2;
R2 = 1 - norm(T_test -  T_sim2)^2 / norm(T_test -  mean(T_test ))^2;

disp(['The R2 of the training set data is：', num2str(R1)])
disp(['The R2 of the test set data is：', num2str(R2)])

%  MAE
mae1 = sum(abs(T_sim1 - T_train)) ./ M ;
mae2 = sum(abs(T_sim2 - T_test )) ./ N ;

disp(['The MAE of the training set data is：', num2str(mae1)])
disp(['The MAE of the test set data is：', num2str(mae2)])

%  MBE
mbe1 = sum(T_sim1 - T_train) ./ M ;
mbe2 = sum(T_sim2 - T_test ) ./ N ;

disp(['The MBE of the training set data is：', num2str(mbe1)])
disp(['The MBE of the test set data is：', num2str(mbe2)])