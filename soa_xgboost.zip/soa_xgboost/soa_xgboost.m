
warning off             
close all               
clear                  
clc                     


res = xlsread('data.xlsx');


num_size = 0.8;                             
outdim = 1;                               
num_samples = size(res, 1);                  
res = res(randperm(num_samples), :);         
num_train_s = round(num_size * num_samples); 
f_ = size(res, 2) - outdim;                  


P_train = res(1: num_train_s, 1: f_)';
T_train = res(1: num_train_s, f_ + 1: end)';
M = size(P_train, 2);

P_test = res(num_train_s + 1: end, 1: f_)';
T_test = res(num_train_s + 1: end, f_ + 1: end)';
N = size(P_test, 2);


[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);


p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';
%% SOA
SearchAgents = 25;     
Max_iterations = 100;       
dimension = 3;                  
Lower_bound = [1,0.1,0.01];        
Upper_bound = [200,1,0.5];      
Position=zeros(1,dimension);
Score=inf; 
Positions=init(SearchAgents,dimension,Upper_bound,Lower_bound);
Convergence=zeros(1,Max_iterations);
l=0;
while l<Max_iterations
    for i=1:size(Positions,1)  
        
        Flag4Upper_bound=Positions(i,:)>Upper_bound;
        Flag4Lower_bound=Positions(i,:)<Lower_bound;
        Positions(i,:)=(Positions(i,:).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               
        
       % Calculate objective function for each search agent
        num_trees = Positions(i,1);                 
        params.eta = Positions(i,2);                 
        params.objective = 'reg:linear';  
        params.max_depth = 3;             
        params.reg_lambda = Positions(i,3);          

       
        model = xgboost_train(p_train, t_train, params, num_trees);

       
        t_sim1 = xgboost_test(p_train, model);
%       t_sim2 = xgboost_test(p_test,  model);

        
        T_sim1 = mapminmax('reverse', t_sim1', ps_output);
%       T_sim2 = mapminmax('reverse', t_sim2', ps_output);
       % fitness = sqrt((sum(T_sim1 - T_train).^2)./ M);
        fitness = sum((T_sim1 - T_train ).^2) ./ M;

        
        if fitness<Score 
            Score=fitness; 
            Position=Positions(i,:);
        end
        

    end
    
    
    Fc=2-l*((2)/Max_iterations); 
    
    for i=1:size(Positions,1)
        for j=1:size(Positions,2)     
                       
            r1=rand(); 
            r2=rand(); 
            
            A1=2*Fc*r1-Fc; 
            C1=2*r2; 
            b=1;             
            ll=(Fc-1)*rand()+1;  
       
            D_alphs=Fc*Positions(i,j)+A1*((Position(j)-Positions(i,j)));                   
            X1=D_alphs*exp(b.*ll).*cos(ll.*2*pi)+Position(j);
            Positions(i,j)=X1;
            
        end
    end
    l=l+1;    
    Convergence(l)=Score;
end

num_trees = Position(1,1);                  
params.eta = Position(1,2);                 
params.objective = 'reg:linear';  
params.max_depth = 3;             
 params.reg_lambda = Position(1,3);          

model = xgboost_train(p_train, t_train, params, num_trees);
% importance = model.importance; 

t_sim1 = xgboost_test(p_train, model);
t_sim2 = xgboost_test(p_test,  model);


T_sim1 = mapminmax('reverse', t_sim1', ps_output);
T_sim2 = mapminmax('reverse', t_sim2', ps_output);


error1 = sqrt(sum((T_sim1 - T_train).^2) ./ M);
error2 = sqrt(sum((T_sim2 - T_test ).^2) ./ N);


figure
plot(1: M, T_train, 'r-*', 1: M, T_sim1, 'b-o', 'LineWidth', 1)
legend('True value','Predicted value')
xlabel('Prediction Sample')
ylabel('Prediction results')
string = {'Comparison of prediction results of training set'; ['RMSE=' num2str(error1)]};
title(string)
xlim([1, M])
grid

figure
plot(1: N, T_test, 'r-*', 1: N, T_sim2, 'b-o', 'LineWidth', 1)
legend('True value','Predicted value')
xlabel('Prediction Sample')
ylabel('Prediction results')
string = {'Comparison of prediction results of test set';['RMSE=' num2str(error2)]};
title(string)
xlim([1, N])
grid

figure
plot(1 : length(Convergence), Convergence, 'LineWidth', 1.5);
title('Fitness curve, 'FontSize', 13);
xlabel('Iterations', 'FontSize', 10);
ylabel('Fitness value', 'FontSize', 10);
xlim([1, length(Convergence)])
grid on

% R2
R1 = 1 - norm(T_train - T_sim1)^2 / norm(T_train - mean(T_train))^2;
R2 = 1 - norm(T_test -  T_sim2)^2 / norm(T_test -  mean(T_test ))^2;

disp(['TR R2：', num2str(R1)])
disp(['TE R2：', num2str(R2)])

%  MAE
mae1 = sum(abs(T_sim1 - T_train)) ./ M ;
mae2 = sum(abs(T_sim2 - T_test )) ./ N ;

disp(['TR MAE：', num2str(mae1)])
disp(['TE MAE：', num2str(mae2)])

%  MBE
mbe1 = sum(T_sim1 - T_train) ./ M ;
mbe2 = sum(T_sim2 - T_test ) ./ N ;

disp(['TR MBE：', num2str(mbe1)])
disp(['TE MBE：', num2str(mbe2)])

%RMSE
disp(['TR RMSE：', num2str(error1)])
disp(['TE RMSE：', num2str(error2)])
